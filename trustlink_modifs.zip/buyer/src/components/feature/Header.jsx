import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '@/hooks/useCart';
import { useCurrencyContext } from '@/lib/CurrencyContext';
import { useI18n } from '@/lib/I18nContext';
import NotificationBell from './NotificationBell';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState('');
  const { totalItems } = useCart();
  const { currency, setCurrency } = useCurrencyContext();
  const { locale, setLocale, t } = useI18n();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) navigate('/catalog?search=' + encodeURIComponent(query.trim()));
  };

  const toggleLocale = () => setLocale(locale === 'fr' ? 'en' : 'fr');

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 bg-white transition-all duration-300 ${scrolled ? 'shadow-sm' : 'border-b border-gray-100'}`}>
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        {/* Desktop */}
        <div className="hidden md:flex items-center h-16 gap-6">
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <img src="/TrustLink_Logo_Bleu-Fonce.png" alt="TrustLink" className="h-9 w-auto" />
          </Link>

          <Link
            to="/catalog"
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-poppins font-semibold text-gray-700 hover:text-[#125C8D] hover:bg-blue-50/60 transition-colors whitespace-nowrap border border-gray-200"
          >
            <i className="ri-store-2-line text-sm text-[#125C8D]" />
            <span>Catalogue</span>
          </Link>

          <form onSubmit={handleSearch} className="flex-1 max-w-xl">
            <div className="flex items-center border border-gray-200 rounded-full overflow-hidden">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('nav.search')}
                className="flex-1 px-5 py-2.5 text-sm outline-none font-inter"
                style={{ color: '#111827' }}
              />
              <button type="submit" className="px-4 py-2.5 text-white flex items-center justify-center rounded-full m-1" style={{ backgroundColor: '#125C8D', minWidth: '36px' }}>
                <i className="ri-search-line text-sm"></i>
              </button>
            </div>
          </form>

          <div className="flex items-center gap-1">
            {/* Currency toggle */}
            <div className="flex items-center bg-gray-100 rounded-full p-0.5 mr-1">
              <button onClick={() => setCurrency('XOF')}
                className={`px-2 py-1 text-xs font-poppins font-semibold rounded-full transition-all cursor-pointer ${currency === 'XOF' ? 'bg-white text-[#125C8D] shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
                FCFA
              </button>
              <button onClick={() => setCurrency('NGN')}
                className={`px-2 py-1 text-xs font-poppins font-semibold rounded-full transition-all cursor-pointer ${currency === 'NGN' ? 'bg-white text-[#125C8D] shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
                NGN
              </button>
            </div>
            {/* Language toggle */}
            <button onClick={toggleLocale}
              className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors text-xs font-poppins font-bold cursor-pointer"
              style={{ color: '#6B7280' }}>
              {locale === 'fr' ? 'FR' : 'EN'}
            </button>
            <Link to="/wishlist" className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors">
              <i className="ri-heart-line text-xl" style={{ color: '#6B7280' }}></i>
            </Link>
            <Link to="/cart" className="relative w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors">
              <i className="ri-shopping-cart-line text-xl" style={{ color: '#6B7280' }}></i>
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 text-xs font-bold text-white rounded-full flex items-center justify-center font-poppins" style={{ backgroundColor: '#FF6A00', fontSize: '10px' }}>
                  {totalItems > 9 ? '9+' : totalItems}
                </span>
              )}
            </Link>
            <NotificationBell />
            <Link to="/account" className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors">
              <i className="ri-user-3-line text-xl" style={{ color: '#6B7280' }}></i>
            </Link>
          </div>
        </div>

        {/* Mobile */}
        <div className="md:hidden">
          <div className="flex items-center justify-between h-14">
            <Link to="/" className="flex items-center gap-2">
              <img src="/TrustLink_Logo_Bleu-Fonce.png" alt="TrustLink" className="h-8 w-auto" />
            </Link>
            <div className="flex items-center gap-1">
              {/* Currency toggle (mobile) */}
              <div className="flex items-center bg-gray-100 rounded-full p-0.5 mr-0.5">
                <button onClick={() => setCurrency('XOF')}
                  className={`px-2.5 py-1.5 text-[11px] font-poppins font-semibold rounded-full transition-all cursor-pointer ${currency === 'XOF' ? 'bg-white text-[#125C8D] shadow-sm' : 'text-gray-500'}`}>
                  FCFA
                </button>
                <button onClick={() => setCurrency('NGN')}
                  className={`px-2.5 py-1.5 text-[11px] font-poppins font-semibold rounded-full transition-all cursor-pointer ${currency === 'NGN' ? 'bg-white text-[#125C8D] shadow-sm' : 'text-gray-500'}`}>
                  NGN
                </button>
              </div>
              <button onClick={toggleLocale}
                className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-[11px] font-poppins font-bold cursor-pointer"
                style={{ color: '#6B7280' }}>
                {locale === 'fr' ? 'FR' : 'EN'}
              </button>
              <Link to="/cart" className="relative w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100">
                <i className="ri-shopping-cart-line text-lg" style={{ color: '#6B7280' }}></i>
                {totalItems > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 text-white rounded-full flex items-center justify-center" style={{ backgroundColor: '#FF6A00', fontSize: '9px' }}>
                    {totalItems}
                  </span>
                )}
              </Link>
              <button onClick={() => setMenuOpen(!menuOpen)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100" aria-label="Menu">
                <i className={`text-lg ${menuOpen ? 'ri-close-line' : 'ri-menu-line'}`} style={{ color: '#111827' }}></i>
              </button>
            </div>
          </div>
          <div className="pb-2">
            <form onSubmit={handleSearch}>
              <div className="flex items-center border border-gray-200 rounded-full overflow-hidden">
                <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('nav.search')} className="flex-1 min-w-0 px-4 py-2 text-base outline-none font-inter" />
                <button type="submit" className="px-3 py-1.5 text-white rounded-full m-1" style={{ backgroundColor: '#125C8D' }}>
                  <i className="ri-search-line text-sm"></i>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 pb-4 max-h-[calc(100dvh-7rem)] overflow-y-auto">
          {[
            { to: '/', label: t('nav.home') },
            { to: '/catalog', label: 'Catalogue' },
            { to: '/account', label: t('nav.account') },
            { to: '/wishlist', label: t('nav.wishlist') },
            { to: '/faq', label: t('support.faq') },
            { to: '/support', label: t('nav.support') },
          ].map(({ to, label }) => (
            <Link key={to} to={to} onClick={() => setMenuOpen(false)} className="block py-3.5 text-sm font-inter border-b border-gray-50 last:border-0" style={{ color: '#111827' }}>
              {label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}
