import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '@/hooks/useCart';
import { useCurrencyContext } from '@/lib/CurrencyContext';
import { supabase } from '@/lib/supabaseClient';
import { useI18n } from '@/lib/I18nContext';

export default function Cart() {
  const { t } = useI18n();
  const { items, loading, removeItem, updateQuantity, totalPrice } = useCart();
  const { formatPrice } = useCurrencyContext();
  const [deliveryFee, setDeliveryFee] = useState(0);

  useEffect(() => {
    supabase.from('escrow_config').select('delivery_fee').limit(1).single()
      .then(({ data }) => { if (data?.delivery_fee) setDeliveryFee(data.delivery_fee); })
      .catch(err => console.error("Error loading delivery fee:", err));
  }, []);

  if (loading) {
    return (
      <div className="pt-28 md:pt-24 pb-12 min-h-screen" style={{ backgroundColor: '#F8FAFC' }}>
        <div className="max-w-[1200px] mx-auto px-4 md:px-6">
          <div className="h-8 w-48 bg-gray-200 rounded animate-pulse mb-12" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white border border-gray-100 rounded-xl p-4 flex gap-4">
                  <div className="w-24 h-24 rounded-lg bg-gray-200 animate-pulse flex-shrink-0" />
                  <div className="flex-1 space-y-3">
                    <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse" />
                    <div className="h-3 bg-gray-200 rounded w-1/4 animate-pulse" />
                    <div className="h-5 bg-gray-200 rounded w-1/6 animate-pulse" />
                    <div className="h-8 bg-gray-200 rounded w-1/3 animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-white border border-gray-100 rounded-xl p-6">
              <div className="h-5 bg-gray-200 rounded w-2/3 animate-pulse mb-4" />
              <div className="space-y-3">
                <div className="h-4 bg-gray-200 rounded animate-pulse" />
                <div className="h-4 bg-gray-200 rounded animate-pulse" />
                <div className="h-4 bg-gray-200 rounded animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="pt-28 md:pt-24 pb-12 min-h-screen" style={{ backgroundColor: '#F8FAFC' }}>
        <div className="max-w-[1200px] mx-auto px-4 md:px-6">
          <h1 className="text-2xl font-poppins font-bold mb-12" style={{ color: '#111827' }}>{t('cart.title')}</h1>
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-20 h-20 rounded-full flex items-center justify-center mb-5" style={{ backgroundColor: '#E1F0F9' }}>
              <i className="ri-shopping-cart-line text-3xl" style={{ color: '#125C8D' }}></i>
            </div>
            <h2 className="text-lg font-poppins font-semibold mb-2" style={{ color: '#111827' }}>{t('cart.empty')}</h2>
            <p className="text-sm font-inter mb-8" style={{ color: '#9CA3AF' }}>{t('cart.emptyDesc')}</p>
            <Link to="/" className="flex items-center gap-2 px-6 py-3 text-white font-poppins font-semibold rounded-full transition-opacity hover:opacity-90" style={{ backgroundColor: '#0E3A4F' }}>
              <i className="ri-store-2-line text-sm"></i>
              {t('cart.continue')}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28 md:pt-24 pb-12 min-h-screen" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <h1 className="text-2xl font-poppins font-bold mb-6" style={{ color: '#111827' }}>
          {t('cart.title')} <span className="text-base font-inter font-normal" style={{ color: '#6B7280' }}>({items.length} {t('cart.items')})</span>
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <article key={item.productId} className="bg-white border border-gray-100 rounded-xl p-4 flex gap-4">
                <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0" style={{ backgroundColor: '#F8FAFC' }}>
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover object-top" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-inter font-medium mb-1 truncate" style={{ color: '#111827' }}>{item.name}</p>
                  {item.selectedSize && <p className="text-xs font-inter mb-0.5" style={{ color: '#6B7280' }}>{t('cart.sizeLabel')}: {item.selectedSize}</p>}
                  {item.selectedColor && <p className="text-xs font-inter mb-2" style={{ color: '#6B7280' }}>{t('cart.colorLabel')}: {item.selectedColor}</p>}
                  <p className="text-sm font-poppins font-bold mb-3" style={{ color: '#125C8D' }}>{formatPrice(item.price)}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                      <button onClick={() => updateQuantity(item.productId, item.quantity - 1)} className="w-8 h-8 flex items-center justify-center hover:bg-gray-50 text-sm font-medium">−</button>
                      <span className="w-10 text-center text-sm font-inter">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="w-8 h-8 flex items-center justify-center hover:bg-gray-50 text-sm font-medium">+</button>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-poppins font-bold" style={{ color: '#111827' }}>{formatPrice(item.price * item.quantity)}</span>
                      <button onClick={() => removeItem(item.productId)} className="transition-colors" style={{ color: '#F87171' }}>
                        <i className="ri-delete-bin-line text-lg"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white border border-gray-100 rounded-xl p-6 sticky top-24">
              <h2 className="text-base font-poppins font-semibold mb-4" style={{ color: '#111827' }}>{t('cart.summary')}</h2>
              <div className="space-y-3 mb-4">
                <div className="flex justify-between text-sm font-inter">
                  <span style={{ color: '#6B7280' }}>{t('cart.subtotal')}</span>
                  <span style={{ color: '#111827' }}>{formatPrice(totalPrice)}</span>
                </div>
                <div className="flex justify-between text-sm font-inter">
                  <span style={{ color: '#6B7280' }}>{t('cart.shipping')}</span>
                  <span style={{ color: '#111827' }}>{formatPrice(deliveryFee)}</span>
                </div>
                <hr className="border-gray-100" />
                <div className="flex justify-between font-poppins font-bold">
                  <span style={{ color: '#111827' }}>{t('cart.total')}</span>
                  <span style={{ color: '#125C8D' }}>{formatPrice(totalPrice + deliveryFee)}</span>
                </div>
              </div>
              <div className="rounded-xl p-3 mb-4" style={{ backgroundColor: '#E1F0F9' }}>
                <div className="flex items-center gap-2">
                  <i className="ri-shield-check-line text-sm" style={{ color: '#125C8D' }}></i>
                  <p className="text-xs font-poppins font-semibold" style={{ color: '#125C8D' }}>{t('cart.secureEscrow')}</p>
                </div>
                <p className="text-xs font-inter mt-1" style={{ color: '#6B7280' }}>{t('cart.escrowDesc')}</p>
              </div>
              <Link to="/checkout" className="block text-center text-white font-poppins font-bold py-3 rounded-full transition-opacity hover:opacity-90" style={{ backgroundColor: '#FF6A00' }}>
                {t('cart.checkout')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
