import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useProducts } from '@/hooks/useProducts';
import HeroBanner from './components/HeroBanner';
import CategoryBar from './components/CategoryBar';
import TrustBanner from './components/TrustBanner';
import ProductGrid from './components/ProductGrid';
import RecentlyViewed from './components/RecentlyViewed';
import { useI18n } from '@/lib/I18nContext';
export default function Home() {
  const { t } = useI18n();
  const [searchParams] = useSearchParams();
  const [sort, setSort] = useState('popular');
  const search = searchParams.get('search') || '';
  const category = searchParams.get('category') || '';
  const { data: products = [], isLoading, error } = useProducts({ category, search });
  const sorted = useMemo(() => {
    const result = [...products];
    if (sort === 'price_asc') result.sort((a, b) => a.price - b.price);
    else if (sort === 'price_desc') result.sort((a, b) => b.price - a.price);
    return result;
  }, [products, sort]);
  const showHero = !search;

  const gridTitle = search
    ? t('home.resultsFor').replace('{query}', search)
    : category
    ? t('home.category').replace('{name}', category.charAt(0).toUpperCase() + category.slice(1))
    : t('home.allProducts');
  return (
    <div className="pt-28 md:pt-20">
      {showHero && <HeroBanner />}
      {showHero && <TrustBanner />}
      <CategoryBar />
      <ProductGrid
        products={sorted}
        title={gridTitle}
        sort={sort}
        onSortChange={setSort}
        isLoading={isLoading}
        error={error}
      />
      {showHero && <RecentlyViewed />}
    </div>
  );
}
